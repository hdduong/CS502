The code is coded in Visual Studio. Please complile the code in Windows. 

BUILD INSTRUCTIONS:
In Mingw, please copy and paste the following command:

gcc base.c state_printer.c student_queue.c z502.c sample.c test.c -o os.exe

